def mult1(x):
	return x*1
	
def mult2(x):
	return x*2
	
def mult3(x):
	return x*3
	
def mult4(x):
	return x*4
	
def mult5(x):
	return x*5
	
def mult6(x):
	return x*6
	
def mult7(x):
	return x*7
	
def mult8(x):
	return x*8
	
def mult9(x):
	return x*9
	