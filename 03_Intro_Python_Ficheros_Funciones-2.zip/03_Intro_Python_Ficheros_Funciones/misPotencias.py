def miCuadrado(x):
	return x**2
	
def miCubo(x):
	return x**3
	
def misOtrasPotencias(b,e):
	return b**e