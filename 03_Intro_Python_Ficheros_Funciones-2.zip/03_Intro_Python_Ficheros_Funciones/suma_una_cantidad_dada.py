def suma1(x):
	return x+1
	
def suma2(x):
	return x+2
	
def suma3(x):
	return x+3